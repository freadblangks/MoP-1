CascLib
=======

An open-source implementation of library for reading CASC storage from Blizzard games since 2014
